import React, { Component } from "react";

class Info extends Component {
  render() {
    const{name,mobile,email,gitHub}=this.props
    return (
      <div>
        <table className="table ">
          <tbody>
            <tr>
              <td>{name}</td>
              <td>{mobile}</td>
              <td>{email}</td>
              <td>
                <a href={gitHub}>
                 {gitHub}
                </a>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }
}

export default Info;
